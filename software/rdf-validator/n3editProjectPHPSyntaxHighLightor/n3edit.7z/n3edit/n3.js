window.onload = function () {
	$(".n3-curie").hover(function ()
	{
		var $this = $(this);

		var $prefix = -1;
		var $array = $this.attr("class").split(" ");
		for($c in $array)
		{
			$C = $array[$c];
			if ( $C.substr(0, 20) == "n3-curie-usesprefix-" )
			{
				$prefix = $C.substr(20);
			}
		}
		if ($prefix != -1)
		{
			$this.closest(".n3").children(".n3-definition-definesprefix-" + $prefix).css('background', 'white');
			$this.closest(".n3").children(".n3-definition-definesprefix-" + $prefix).css('outline', '1px solid #ccc');
		}
	},
	function (){
		var $this = $(this);
		var $prefix = -1;
		var $array = $this.attr("class").split(" ");
		for($c in $array)
		{
			$C = $array[$c];
			if ( $C.substr(0, 20) == "n3-curie-usesprefix-" )
			{
				$prefix = $C.substr(20);
			}
		}
		if ($prefix != -1)
		{
			$this.closest(".n3").children(".n3-definition-definesprefix-" + $prefix).css('background', 'transparent');
			$this.closest(".n3").children(".n3-definition-definesprefix-" + $prefix).css('outline', 'none');
		}
	});
};

