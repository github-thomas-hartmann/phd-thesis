<?php ini_set('display_errors', false); ?>
<!doctype html>
<title>Notation 3 Editor</title>
<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>
<link href="n3.css" rel="stylesheet" type="text/css"/>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
<script src="jquery.equalheights.js"></script>
<script src="n3.js"></script>

<script>
	var $dirty = 1;
	$(document).ready(function() {
		var $tabset = $("#tabs").tabs({ fxAutoHeight: true });
		$tabset.bind('tabsselect', function ($event, $ui) {
			if (!$dirty) return true;
			if ($ui.index == 1)
			{
				$.post('ajax-highlight.php',
					{ input: $("#te").val() },
					function ($data) {
						if ($data.html)
						{
							$("#preview").html($data.html);
						}
						else
						{
							$("#preview").html('ERROR');
						}
						$dirty = 0;
					}, 'json');
			}
		});
		$("#tabs > div").equalHeights();
	});
	function dirty ()
	{
		$('#save_output').removeClass('fresh');
		$dirty=1;
	}
	function sure ()
	{
		if ($("#te").val()=="")
			return true;
		return window.confirm("Are you sure you want to abandon your current editing and load something else?");
	}
	function pastebin ()
	{
		$.post('proxy.php',
			{
				proxy_url:         'http://pastebin.com/api_public.php',
				proxy_verb:        'POST',
				paste_code:        $("#te").val(),
				paste_name:        $("#save_name").val(),
				paste_expire_date: $("#save_for").val(),
				paste_subdomain:   "esw"
			},
			function ($data) {
				$('#save_output').addClass('fresh');
				$line1 = "<b>Saved to: </b> <a href=\""+$data+"\">"+$data+"</a>";
				$data = "http://buzzword.org.uk/2010/n3edit/?esw=" + $data.substr(24);
				$line2 = "<b>Edit link: </b> <a href=\""+$data+"\">"+$data+"</a>";
				$('#save_output').html($line1 + "<br />" +$line2);
			});
	}
	function wikisave ()
	{
		$.ajax({
			'type': 'POST',
			url:    'proxy.php',
			data: {
				proxy_url:         'http://wiki.ontologi.es/'+$('#wikipage').val(),
				proxy_verb:        'POST',
				data:               $("#te").val(),
				format:             $("#wikiformat").val()
			},
			success: function ($data) {
				window.alert("Data saved back to wiki.");
			},
			error: function ($xhr) {
				window.alert("Error saving data: " + $xhr.statusText);
			}
			});
	}
</script>

<h1 style="margin-bottom:2px">Notation 3 Editor</h1>

<p style="margin-top:0"><small>Online editing and syntax highlighting for Notation 3,
Turtle, N-Triples, TriG, N-Quads, SPARQL Query and SPARQL Update.</small></p>

<!-- <p><small><i><b>New!</b> Integration with esw.pastebin.com (load 
snippets from esw.pastebin.com, and save snippets back),
prefix.cc (start with some default prefixes) and wiki.ontologi.es
(load and save data).</i></small></p> -->

<div id="tabs">
	<ul>
		<li><a href="#editor"><span>Editor</span></a></li>
		<li><a href="#preview"><span>Preview</span></a></li>
		<li><a href="#open"><span>Load</span></a></li>
		<li><a href="#save"><span>Share</span></a></li>
		<li><a href="#wikisave"><span>Publish</span></a></li>
		<li><a href="#help"><span>Help</span></a></li>
	</ul>
	<div id="editor">
		<textarea id="te" rows="18" cols="60" style="width:100%" onchange="dirty();"><?php	
			if (isset($_GET['load']))
			{
				require 'HTTP/Client.php';
				$client = new HTTP_Client;
				$client->setDefaultHeader('Accept', 'text/turtle, text/n3, application/sparql-query');
				$client->setDefaultHeader('Accept-Encoding', 'identity');
				if ($client->get($_GET['load']) == 200)
				{
					$response = $client->currentResponse();
					print htmlentities($response['body']);
				}
			}
			elseif (isset($_GET['esw']))
			{
				require 'HTTP/Client.php';
				$client = new HTTP_Client;
				$client->setDefaultHeader('Accept-Encoding', 'identity');
				if ($client->get('http://esw.pastebin.com/download.php?i=' . $_GET['esw']) == 200)
				{
					$response = $client->currentResponse();
					print htmlentities($response['body']);
				}
			}
			elseif (strlen($_GET['wiki']))
			{
				require 'HTTP/Client.php';
				$client = new HTTP_Client;
				$client->setDefaultHeader('Accept', 'text/n3');
				$client->setDefaultHeader('Accept-Encoding', 'identity');
				if ($client->get('http://wiki.ontologi.es/' . $_GET['wiki']) == 200)
				{
					$response = $client->currentResponse();
					print htmlentities($response['body']);
				}
			}
			elseif (isset($_GET['prefix']))
			{
				require 'HTTP/Client.php';
				$client = new HTTP_Client;
				$client->setDefaultHeader('Accept', 'text/plain');
				$client->setDefaultHeader('Accept-Encoding', 'identity');
				if ($client->get('http://prefix.cc/' . $_GET['prefix'] . ".ttl.plain") == 200)
				{
					$response = $client->currentResponse();
					print htmlentities($response['body']);
				}
			}
			elseif (isset($_GET['sprefix']))
			{
				require 'HTTP/Client.php';
				$client = new HTTP_Client;
				$client->setDefaultHeader('Accept', 'text/plain');
				$client->setDefaultHeader('Accept-Encoding', 'identity');
				if ($client->get('http://prefix.cc/' . $_GET['sprefix'] . ".file.sparql") == 200)
				{
					$response = $client->currentResponse();
					print htmlentities($response['body']);
				}
			}
		?></textarea>
	</div>
	<div id="preview"></div>
	<div id="open">
		<form action="/2010/n3edit/" method="get" onsubmit="return sure();">
			<p><strong>Load from URL:</strong></p>
			<p>
				<label for="load">URL:</label>
				<input id="load" name="load" value="" type="url" />
				<input type="submit" value="Load" />
			</p>
		</form>
		<hr style="width:90%;color:silver;background:silver;border:1px solid silver;margin:2em 0"  />
		<form action="/2010/n3edit/" method="get" onsubmit="return sure();">
			<p><strong>Load from wiki.ontologi.es:</strong></p>
			<p>
				<label for="wiki">Wiki Page:</label>
				<input id="wiki" name="wiki" value="" />
				<input type="submit" value="Load" />
			</p>
		</form>
	</div>
	<div id="save">
		<p><strong>Share using esw.pastebin.com:</strong></p>
		<p>
			<label for="save_name">Name/Title:</label>
			<input id="save_name" value="n3edit user" />
			<button onclick="pastebin();">Share</button>
		</p>
		<p>
			<select id="save_for">
				<option value="10M">Retain for a few minutes</option>
				<option value="1H">Retain for an hour</option>
				<option value="1D">Retain for a day</option>
				<option value="1M" selected="selected">Retain for a month</option>
				<option value="N">Retain forever</option>
			</select>
		</p>
		<div id="save_output"></div>
	</div>
	<div id="wikisave">
		<p><strong>Publish to wiki.ontologi.es:</strong></p>
		<p>
			<label for="wikipage">Wiki Page:</label>
			<input id="wikipage" value="<?php echo htmlentities($_GET['wiki']); ?>" />
			<button onclick="wikisave();">Publish</button>
		</p>
		<p>
			<select id="wikiformat">
				<option value="text/plain">Interpret as N-Triples</option>
				<option value="text/turtle">Interpret as Turtle</option>
				<option value="text/n3" selected="selected">Interpret as Notation 3</option>
				<option value="application/json">Interpret as RDF/JSON</option>
			</select>
		</p>
		<p>Other formats cannot be published to wiki.ontologi.es.</p>
	</div>
	<div id="help">
		<p>This is an online editor and syntax highlighter for Notation 3 and
		related languages. Here's the languages it supports:</p>
		<ul>
			<li><a href="http://www.w3.org/DesignIssues/Notation3">Notation 3</a></li>
			<li><a href="http://www.w3.org/TeamSubmission/turtle/">Turtle</a></li>
			<li><a href="http://www.w3.org/TR/rdf-testcases/#ntriples">N-Triples</a></li>
			<li><a href="http://www4.wiwiss.fu-berlin.de/bizer/TriG/">TriG</a></li>
			<li><a href="http://sw.deri.org/2008/07/n-quads/">N-Quads</a></li>
			<li><a href="http://www.w3.org/TR/rdf-sparql-query/">SPARQL Query 1.0</a></li>
			<li><a href="http://www.w3.org/Submission/SPARQL-Update/">SPARQL Update</a></li>
			<li><a href="http://json.org/">JSON</a> mostly works, by luck rather than design</li>
		</ul>
		<p>Once you've got a snippet you want to share, you can post it to
		pastebin.com in one easy click. Or if it's something that deserves a more
		permanent URL, you can publish it to a data wiki.</p>
	</div>
</div>